# Government data: national quality summary

This assessment checks whether Obrasgov records and census data can support a study of infrastructure distance, neighbourhood income and racial composition.

[Detailed annex: methods, diagnostic tables and all eleven figures](gov_data_quality_annex.md) · [Variable codebook](../../docs/codebook.md)

## Key findings

<details>
<summary>Executable summary: read current pipeline results</summary>

<!-- brazil:cell gov_data_quality_summary -->
```python
import pandas as pd
from brazil_project.reporting import table, markdown
summary = report_json("gov-data-quality")
attr, loc, census = summary["attributes"], summary["locations"], summary["census"]
coverage = ctx.table("gov-data-quality", "census_annual_coverage")
coverage_2022 = coverage.loc[coverage.year.eq(2022)].set_index("measure")
joint = coverage_2022.loc["joint_fully_observed"]
threshold = loc["shared_coordinate_threshold"]
shared_pct = 100 * loc["shared_point_projects"] / loc["valid_point_projects"] if loc["valid_point_projects"] else None
shared_text = f"{shared_pct:.2f}%" if shared_pct is not None else "Unavailable percentage"
markdown(f"**Scope:** {summary['distinct_projects']:,} project IDs in {summary['source_rows']:,} original rows, "
         + f"{summary['geometry_components']:,} geometry components and {census['n_common_areas']:,} national census comparison areas. "
         + f"**Review date:** {summary['as_of_date']}.")
rows = [
    {"Check": "Project counting", "Finding": f"{summary['source_rows'] - summary['distinct_projects']:,} rows repeat a project ID.",
     "Implication": "Count distinct IDs; taxonomy-expanded rows are not necessarily errors."},
    {"Check": "Shared coordinates", "Finding": f"{loc['shared_point_projects']:,} of {loc['valid_point_projects']:,} finite-point project IDs ({shared_text}) have a point shared by at least {threshold} IDs.",
     "Implication": "Review locations before interpreting distances; sharing does not prove an error."},
    {"Check": "Category signals", "Finding": f"{attr['projects_with_category_review']:,} IDs combine education wording/provider with a water/ports category.",
     "Implication": "Heuristic review signal; verify categories before sector-specific comparisons."},
    {"Check": "Actual dates", "Finding": f"Starts: {attr['projects_with_effective_start']:,} IDs ({attr['projects_with_effective_start_pct']:.2f}%); finishes: {attr['projects_with_effective_finish']:,} ({attr['projects_with_effective_finish_pct']:.2f}%).",
     "Implication": "Registration and planned dates cannot establish construction, completion or opening dates."},
    {"Check": "Planned investment", "Finding": f"{attr['projects_with_budget_001']:,} IDs ({attr['projects_with_budget_001_pct']:.2f}%) report R$0.01.",
     "Implication": "Verify tiny amounts before investment weighting; planned budgets are not realised spending."},
    {"Check": "Joint census coverage, 2022", "Finding": f"{int(joint['n_common_areas']):,} of {census['n_common_areas']:,} areas ({joint['share_pct']:.2f}%) have fully observed race and complete usable income.",
     "Implication": "A conservative coverage diagnostic, not an automatic analysis sample or exclusion."},
]
table(pd.DataFrame(rows), "Project findings use distinct IDs; the shared-location denominator includes finite world-range points, including existing quarantined points. Census findings count areas, not residents.")
saved, observed = coverage_2022.loc["race_ratio_available"], coverage_2022.loc["race_ratio_fully_observed"]
markdown(f"**Why census completeness matters:** saved racial shares are available for {saved['share_pct']:.2f}% of areas, "
         + f"but only {observed['share_pct']:.2f}% have fully observed contributing race inputs. "
         + "The preserved method can treat missing racial components as zero.")
figures = summary["figures"]
for name, heading, caption in [
    ("location-overview.png", "Where shared coordinates occur",
     f"Red sites contain at least {threshold} different project IDs at the exact same coordinates. Background sites include previously quarantined points; lines, polygons and invalid/empty points are omitted. This identifies review locations, not verified facilities."),
    ("date-coverage.png", "Why project timing needs verification",
     "Reported actual dates are scarce. The chart compares registration, plans and actual events; none independently establishes an operational opening."),
    ("income-coverage.png", "Why saved census values are not always complete",
     "All national comparison areas form the denominator. Saved values can remain computable despite incomplete contributing inputs; the bars describe coverage, not racial disparities in infrastructure proximity."),
]:
    if name not in figures:
        raise RuntimeError("Missing required summary figure: " + name)
    markdown("### " + heading)
    report_image(figures[name])
    markdown(caption)
```

</details>

<!-- brazil:output gov_data_quality_summary begin -->
**Scope:** 129,961 project IDs in 134,929 original rows, 230,356 geometry components and 287,178 national census comparison areas. **Review date:** 2026-10-07.

Project findings use distinct IDs; the shared-location denominator includes finite world-range points, including existing quarantined points. Census findings count areas, not residents.

<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Check</th>
      <th>Finding</th>
      <th>Implication</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Project counting</td>
      <td>4,968 rows repeat a project ID.</td>
      <td>Count distinct IDs; taxonomy-expanded rows are not necessarily errors.</td>
    </tr>
    <tr>
      <td>Shared coordinates</td>
      <td>27,953 of 127,081 finite-point project IDs (22.00%) have a point shared by at least 25 IDs.</td>
      <td>Review locations before interpreting distances; sharing does not prove an error.</td>
    </tr>
    <tr>
      <td>Category signals</td>
      <td>25,216 IDs combine education wording/provider with a water/ports category.</td>
      <td>Heuristic review signal; verify categories before sector-specific comparisons.</td>
    </tr>
    <tr>
      <td>Actual dates</td>
      <td>Starts: 1,750 IDs (1.35%); finishes: 1,241 (0.95%).</td>
      <td>Registration and planned dates cannot establish construction, completion or opening dates.</td>
    </tr>
    <tr>
      <td>Planned investment</td>
      <td>20,532 IDs (15.80%) report R$0.01.</td>
      <td>Verify tiny amounts before investment weighting; planned budgets are not realised spending.</td>
    </tr>
    <tr>
      <td>Joint census coverage, 2022</td>
      <td>256,907 of 287,178 areas (89.46%) have fully observed race and complete usable income.</td>
      <td>A conservative coverage diagnostic, not an automatic analysis sample or exclusion.</td>
    </tr>
  </tbody>
</table>

**Why census completeness matters:** saved racial shares are available for 99.24% of areas, but only 89.49% have fully observed contributing race inputs. The preserved method can treat missing racial components as zero.

### Where shared coordinates occur

![Generated figure](assets/813d8fa6341056e6e7c9ee733cf9834c24a44df78a9d5a687f5d2a91b5cec940.png)

Red sites contain at least 25 different project IDs at the exact same coordinates. Background sites include previously quarantined points; lines, polygons and invalid/empty points are omitted. This identifies review locations, not verified facilities.

### Why project timing needs verification

![Generated figure](assets/1bac5ac585ce6a91e8dc52563651a2567c115e4046d373f0d05ab7deb229f2c1.png)

Reported actual dates are scarce. The chart compares registration, plans and actual events; none independently establishes an operational opening.

### Why saved census values are not always complete

![Generated figure](assets/c1d179b871b2719a0ebf047d210e00206c6c2c3623e30888b4378401b5bb5bf5.png)

All national comparison areas form the denominator. Saved values can remain computable despite incomplete contributing inputs; the bars describe coverage, not racial disparities in infrastructure proximity.
<!-- brazil:output gov_data_quality_summary end -->

## How to read this analysis

These are quality-review flags. Income is a household-head-weighted area mean; racial shares describe residents. A saved value or an eligible on-land point does not guarantee complete inputs or accurate locations. The [annex](gov_data_quality_annex.md) gives definitions, state comparisons, sensitivity checks and source-record examples.

## Interpretation and limits

**Review location clusters, category signals, tiny budgets and missing census components before choosing the distance-analysis sample.** This assessment does not correct records or apply new exclusions. Aggregate income and racial composition cannot identify individual income by race or establish causal infrastructure effects. Distances and regression have not been computed.

## Reproduce and inspect the code

```bash
brazil-project run gov-data-quality --config project.toml
```

This command updates both the summary and annex. Use `brazil-project report gov_data_quality --from-saved --config project.toml` to refresh both from verified existing artifacts.

[Processing: gov_quality.py → run()](../../code/brazil_project/infrastructure/gov_quality.py#L289) → `data/intermediate/gov-data-quality/` → executable report cells. [Presentation: reporting.py → table()](../../code/brazil_project/reporting.py#L13) · [Pipeline/source guide](../../docs/pipeline-source.md) · [Process and script audit](../../docs/gov-data-quality-process.md). Detailed code links and provenance remain in the annex.
